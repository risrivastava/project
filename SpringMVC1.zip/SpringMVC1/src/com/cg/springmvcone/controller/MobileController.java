package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Mobile;
import com.cg.springmvcone.service.IMobileService;

@Controller
public class MobileController {
	@Autowired
	IMobileService mobileservice;
	@RequestMapping(value="/home")
	public String getAllMobiles(@ModelAttribute("my")Mobile mob,Map<String,Object> m){
		List<String> mylist= new ArrayList<>();
		mylist.add("Android");
		mylist.add("Iphone");
		mylist.add("Windows");
		mylist.add("Jio");
	
		m.put("cato",mylist);
		return "AddMobile";
		//System.out.println("Welcome to my world---SPRING MVC");
		
	}
	@RequestMapping(value="/addData",method=RequestMethod.POST)
	public String addMobileData(@ModelAttribute("my")Mobile mobile){
		mobileservice.addMobile(mobile);
		return "success";
		
	}
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView showAllMobileData(){
		List<Mobile> allMobile=mobileservice.showAllMobile();
		System.out.println(allMobile);
		
		return new ModelAndView("mobileshow", "data", allMobile);//will come on L1 //
		
	}
}
